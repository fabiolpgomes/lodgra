# PLANO DO PROJETO HOME STAY

## Objetivo Macro
Sistema de gestão completa de aluguel/alojamento de curta, média e longa duração para múltiplas plataformas (Airbnb, Booking e outras).

## Contexto Estratégico
- **Uso**: Interno (MVP)
- **Escala Inicial**: 10 propriedades
- **Integrações Prioritárias**: Airbnb + Booking.com
- **Diferencial Competitivo**: 
  - UX leve, rápido e intuitivo (vs Hostfully lento)
  - Sincronização robusta e confiável entre plataformas
  - Interface simples, sem curva de aprendizado longa

## Stack Tecnológica Proposta
### Frontend
- **Next.js 14** (React framework) - Rápido, moderno, fácil deploy
- **Tailwind CSS** - Styling rápido sem CSS complexo
- **shadcn/ui** - Componentes prontos e bonitos

### Backend
- **Next.js API Routes** - Backend no mesmo projeto (simplicidade)
- **Supabase** - Database + Auth + Storage (PostgreSQL gerenciado)
- **Webhooks** - Para sincronização em tempo real

### Integrações
- **Airbnb API** (via hospedable-airbnb ou similar)
- **Booking.com API** (XML ou Connectivity API)
- **iCal** - Fallback para sincronização de calendários

### Deploy
- **Vercel** - Deploy automático, zero config
- **Supabase Cloud** - Database hospedado

**Por quê essa stack?**
✅ Tudo em JavaScript/TypeScript (uma linguagem só)
✅ Next.js = Frontend + Backend juntos (menos complexidade)
✅ Supabase = Database pronto, sem configurar servidor
✅ Vercel = Deploy com 1 clique
✅ Comunidade gigante = muitos tutoriais e ajuda

## Arquitetura MVP (Fases)

### FASE 1: Base (Semana 1-2)
- [ ] Setup do projeto Next.js + Supabase
- [ ] Schema do banco de dados
- [ ] Autenticação básica
- [ ] CRUD de propriedades (manual)
- [ ] Dashboard simples

### FASE 2: Calendário (Semana 3)
- [ ] Calendário unificado (view)
- [ ] Importação iCal (Airbnb/Booking)
- [ ] Detecção de conflitos
- [ ] Sincronização bidirecional

### FASE 3: Reservas (Semana 4)
- [ ] Listagem de reservas
- [ ] Detalhes de hóspedes
- [ ] Status de reservas
- [ ] Filtros e busca

### FASE 4: Integração Airbnb (Semana 5-6)
- [ ] Conexão API Airbnb
- [ ] Sync automático de reservas
- [ ] Sync de calendário
- [ ] Webhooks para updates em tempo real

### FASE 5: Integração Booking (Semana 7-8)
- [ ] Conexão API Booking.com
- [ ] Sync automático de reservas
- [ ] Sync de calendário
- [ ] Webhooks para updates em tempo real

### FASE 6: Financeiro Básico (Semana 9)
- [ ] Registro de receitas (por reserva)
- [ ] Registro de despesas
- [ ] Dashboard financeiro simples
- [ ] Relatório mensal

## Funcionalidades Futuras (Pós-MVP)
- Comunicação automatizada com hóspedes
- Gestão de limpeza e manutenção
- Multi-moeda e impostos
- App mobile
- Relatórios avançados
- IA para precificação dinâmica

## Status Atual
- [x] Definição de escopo e objetivos
- [x] Escolha de stack tecnológica
- [x] Criar schema do banco de dados
- [x] Setup Inicial do projeto Next.js + Supabase
- [x] Configurar Supabase Cloud
- [x] Migrar schema para Supabase
- [x] **Protótipo da primeira tela (Dashboard + Propriedades)**

## ✅ Concluído Agora
- Dashboard com estatísticas
- Página de listagem de propriedades
- Formulário de nova propriedade
- Navegação entre páginas

## 🎯 Próximos Passos
- [ ] Testar criação de propriedade
- [ ] Criar página de detalhes da propriedade
- [ ] Implementar edição/exclusão
- [ ] Criar listagem de reservas
- [ ] Criar calendário unificado
