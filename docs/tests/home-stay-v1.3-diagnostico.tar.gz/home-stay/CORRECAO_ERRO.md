# 🔧 CORREÇÃO DE ERRO - "Failed to Fetch"

## ❌ Problema Identificado

O erro "TypeError: Failed to fetch" acontece porque:
1. O arquivo `.env.local` não está configurado corretamente
2. As credenciais do Supabase estão faltando ou incorretas
3. O servidor precisa ser reiniciado após configurar

---

## ✅ SOLUÇÃO PASSO A PASSO

### Passo 1: Verificar se o .env.local existe

```bash
cd ~/Projetos/home-stay
ls -la .env.local
```

**Se não existir**, copie do exemplo:
```bash
cp .env.local.example .env.local
```

### Passo 2: Pegar credenciais do Supabase

1. Acesse: https://supabase.com/dashboard
2. Entre no seu projeto
3. Clique no ícone de **Settings** (engrenagem) no menu lateral
4. Clique em **API**
5. Você verá:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **anon public**: (clique em "Copy" para copiar a chave)
   - **service_role**: (clique em "Reveal" e depois "Copy")

### Passo 3: Editar o .env.local

Abra o arquivo `.env.local` no seu editor preferido:

```bash
# VS Code:
code .env.local

# Ou qualquer editor de texto
open -a TextEdit .env.local
```

Cole suas credenciais:

```env
NEXT_PUBLIC_SUPABASE_URL=https://SEU-PROJETO-AQUI.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.sua-chave-anon-aqui
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.sua-chave-service-role-aqui
```

**IMPORTANTE:** 
- Substitua TODOS os valores
- Não deixe espaços antes ou depois do `=`
- Não coloque aspas nas chaves

### Passo 4: Reiniciar o Servidor

```bash
# Pare o servidor (Ctrl+C no terminal onde está rodando)
# Depois inicie novamente:
npm run dev
```

### Passo 5: Testar Novamente

1. Acesse: http://localhost:3000/properties/new
2. Preencha o formulário
3. Clique em "Salvar Propriedade"
4. Deve funcionar! ✅

---

## 🔍 DIAGNÓSTICO RÁPIDO

Para verificar se está tudo OK, execute:

```bash
node diagnose.js
```

Você deve ver:
```
✅ NEXT_PUBLIC_SUPABASE_URL: Definida
✅ NEXT_PUBLIC_SUPABASE_ANON_KEY: Definida
✅ SUPABASE_SERVICE_ROLE_KEY: Definida
```

---

## ⚠️ Checklist de Verificação

Marque conforme for resolvendo:

- [ ] Arquivo `.env.local` existe na raiz do projeto
- [ ] Credenciais do Supabase foram copiadas do dashboard
- [ ] Não há espaços extras nas linhas do .env.local
- [ ] Servidor foi reiniciado após configurar
- [ ] Navegador foi atualizado (F5 ou Cmd+R)

---

## 🐛 Ainda com Erro?

### Erro: "Invalid API key"
**Causa**: Chave incorreta ou com espaços
**Solução**: 
1. Copie novamente do Supabase Dashboard
2. Certifique-se que copiou a chave COMPLETA
3. Verifique se não tem quebra de linha no meio

### Erro: "Failed to fetch" persiste
**Causa**: Variável de ambiente não carregou
**Solução**:
1. Execute: `node diagnose.js`
2. Se mostrar "NÃO DEFINIDA", o .env.local está no lugar errado
3. Verifique se está em: `~/Projetos/home-stay/.env.local`
4. Não deve estar em subpastas

### Erro: "Project paused"
**Causa**: Projeto Supabase foi pausado por inatividade
**Solução**:
1. Acesse o Supabase Dashboard
2. Clique em "Resume project"
3. Aguarde 1-2 minutos

---

## 📞 Exemplo de .env.local Correto

```env
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://abcdefghijklm.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiY2RlZmdoaWprbG0iLCJyb2xlIjoiYW5vbiIsImlhdCI6MTY5MDAwMDAwMCwiZXhwIjoyMDA1NTc2MDAwfQ.exemplo-de-token-anon-key-completo
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiY2RlZmdoaWprbG0iLCJyb2xlIjoic2VydmljZV9yb2xlIiwiaWF0IjoxNjkwMDAwMDAwLCJleHAiOjIwMDU1NzYwMDB9.exemplo-de-token-service-role-key-completo
```

---

## ✅ Próximo Passo

Depois de corrigir, me avise:
- ✅ Funcionou!
- ⚠️ Ainda dá erro (envie screenshot do erro)

Vou atualizar o pacote com a correção de hydration também.
