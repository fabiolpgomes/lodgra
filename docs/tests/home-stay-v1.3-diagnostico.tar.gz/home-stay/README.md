# 🏠 Home Stay - Sistema de Gestão de Alojamentos

Sistema completo de gestão de aluguel/alojamento multi-plataforma (Airbnb, Booking.com e outras).

## 🎯 Características Principais

- ✅ Gestão de 10+ propriedades
- ✅ Sincronização bidirecional Airbnb + Booking.com
- ✅ Calendário unificado
- ✅ Prevenção de conflitos de reservas
- ✅ Dashboard financeiro
- ✅ UX rápido e intuitivo

## 🚀 Stack Tecnológica

- **Frontend**: Next.js 14 + React + TypeScript
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Deploy**: Vercel
- **Ícones**: Lucide React
- **Gráficos**: Recharts
- **Formulários**: React Hook Form + Zod
- **Datas**: date-fns

## 📋 Pré-requisitos

- Node.js 18+ 
- npm ou yarn
- Conta no Supabase (gratuita)
- Conta no Vercel (gratuita) - para deploy

## 🛠️ Setup do Projeto

### 1. Clone o repositório
```bash
# Se usando Git
git clone <seu-repo>
cd home-stay
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Configure o Supabase

#### 3.1 Crie um projeto no Supabase
1. Acesse [https://supabase.com](https://supabase.com)
2. Clique em "Start your project"
3. Crie uma organização (se ainda não tiver)
4. Crie um novo projeto:
   - Nome: `home-stay` (ou o que preferir)
   - Database Password: escolha uma senha forte
   - Region: escolha a mais próxima (ex: Europe West - London)
   - Plano: Free

#### 3.2 Execute o Schema SQL
1. No dashboard do Supabase, vá em **SQL Editor**
2. Clique em "New query"
3. Copie todo o conteúdo do arquivo `supabase-schema.sql`
4. Cole no editor e clique em "Run"
5. Aguarde a confirmação "Success. No rows returned"

#### 3.3 Configure as variáveis de ambiente
1. No dashboard do Supabase, vá em **Settings** → **API**
2. Copie:
   - **Project URL** (ex: https://xxxxx.supabase.co)
   - **anon public** key
3. Renomeie `.env.local.example` para `.env.local`
4. Substitua os valores:

```env
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-anon-aqui
```

### 4. Execute o projeto localmente

```bash
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000) no navegador.

## 📁 Estrutura do Projeto

```
home-stay/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── layout.tsx         # Layout principal
│   │   └── page.tsx           # Página inicial
│   ├── components/            # Componentes React
│   │   └── ui/               # Componentes de UI reutilizáveis
│   ├── lib/                  # Bibliotecas e utilitários
│   │   └── supabase/        # Clients do Supabase
│   ├── types/               # Tipos TypeScript
│   │   └── database.ts      # Tipos do banco de dados
│   ├── hooks/              # Custom React Hooks
│   └── utils/              # Funções auxiliares
├── public/                 # Arquivos estáticos
├── supabase-schema.sql    # Schema SQL completo
├── DATABASE_SCHEMA.md     # Documentação do schema
├── PLAN.md               # Roadmap do projeto
├── RULES.md              # Regras de desenvolvimento
└── WORKFLOW.md           # Fluxo de trabalho
```

## 🗄️ Schema do Banco de Dados

O banco possui 8 tabelas principais:

1. **properties** - Propriedades/imóveis
2. **platforms** - Plataformas (Airbnb, Booking, etc)
3. **property_listings** - Anúncios das propriedades em cada plataforma
4. **guests** - Hóspedes
5. **reservations** - Reservas
6. **calendar_blocks** - Bloqueios de calendário
7. **sync_logs** - Logs de sincronização
8. **financial_transactions** - Transações financeiras

Ver detalhes completos em `DATABASE_SCHEMA.md`.

## 🚦 Roadmap MVP

### ✅ Fase 1: Base (Concluído)
- [x] Setup Next.js + Supabase
- [x] Schema do banco de dados
- [x] Tipos TypeScript

### ⏳ Fase 2: CRUD Básico
- [ ] Dashboard inicial
- [ ] CRUD de propriedades
- [ ] Autenticação básica

### ⏳ Fase 3: Calendário
- [ ] Calendário unificado
- [ ] Importação iCal
- [ ] Detecção de conflitos

### ⏳ Fase 4: Integrações
- [ ] Integração Airbnb API
- [ ] Integração Booking.com API
- [ ] Sincronização automática

### ⏳ Fase 5: Financeiro
- [ ] Dashboard financeiro
- [ ] Relatórios

## 🔧 Comandos Úteis

```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Iniciar produção localmente
npm start

# Linting
npm run lint

# Verificação de tipos TypeScript
npx tsc --noEmit
```

## 📝 Próximos Passos

1. ✅ Projeto criado e configurado
2. ⏳ Configurar Supabase (seguir instruções acima)
3. ⏳ Criar primeira tela (Dashboard)
4. ⏳ Implementar CRUD de propriedades
5. ⏳ Desenvolver calendário unificado

## 🤝 Governança do Projeto

Este projeto segue um framework de governança rigoroso:

- **RULES.md** - Regras e diretrizes obrigatórias
- **WORKFLOW.md** - Fluxo de trabalho passo-a-passo
- **PLAN.md** - Roadmap detalhado
- **LESSONS.md** - Aprendizados documentados

**IMPORTANTE**: Sempre ler RULES.md antes de fazer mudanças no código.

## 📚 Documentação Adicional

- [Next.js Docs](https://nextjs.org/docs)
- [Supabase Docs](https://supabase.com/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [TypeScript](https://www.typescriptlang.org/docs)

## 📄 Licença

Uso interno - Home Stay Project
