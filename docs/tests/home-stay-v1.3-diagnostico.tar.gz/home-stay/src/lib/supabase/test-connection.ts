import { createClient } from '@/lib/supabase/client'

/**
 * Script de teste para verificar conexão com Supabase
 * Execute este teste após configurar o .env.local
 */

export async function testSupabaseConnection() {
  console.log('🔍 Testando conexão com Supabase...\n')

  const supabase = createClient()

  try {
    // Teste 1: Verificar conexão básica
    console.log('📡 Teste 1: Verificando conexão...')
    const { data, error } = await supabase.from('platforms').select('*')
    
    if (error) {
      console.error('❌ Erro na conexão:', error.message)
      return false
    }

    console.log('✅ Conexão estabelecida!')
    console.log(`📊 Plataformas encontradas: ${data?.length || 0}\n`)

    // Teste 2: Listar plataformas
    if (data && data.length > 0) {
      console.log('📋 Plataformas cadastradas:')
      data.forEach((platform: any) => {
        console.log(`   - ${platform.name} (${platform.code})`)
      })
    } else {
      console.log('⚠️  Nenhuma plataforma cadastrada ainda.')
      console.log('💡 Execute o SQL seed no Supabase Dashboard.\n')
    }

    // Teste 3: Verificar outras tabelas
    console.log('\n🔍 Verificando estrutura do banco...')
    
    const tables = [
      'properties',
      'property_listings', 
      'guests',
      'reservations',
      'calendar_blocks',
      'sync_logs',
      'financial_transactions'
    ]

    for (const table of tables) {
      const { count, error } = await supabase
        .from(table)
        .select('*', { count: 'exact', head: true })
      
      if (error) {
        console.log(`   ❌ ${table}: ${error.message}`)
      } else {
        console.log(`   ✅ ${table}: ${count || 0} registros`)
      }
    }

    console.log('\n🎉 Teste concluído com sucesso!')
    return true

  } catch (error) {
    console.error('❌ Erro inesperado:', error)
    return false
  }
}

// Executar automaticamente se for chamado diretamente
if (typeof window !== 'undefined') {
  testSupabaseConnection()
}
