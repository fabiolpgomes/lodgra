import Link from 'next/link'
import { Building2, MapPin, Users, Plus, Home } from 'lucide-react'
import { createClient } from '@/lib/supabase/server'

export default async function PropertiesPage() {
  const supabase = await createClient()
  
  // Buscar propriedades do banco
  const { data: properties, error } = await supabase
    .from('properties')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Erro ao buscar propriedades:', error)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Home Stay</h1>
            </div>
            <nav className="flex gap-6">
              <Link href="/" className="text-gray-600 hover:text-gray-900">
                Dashboard
              </Link>
              <Link href="/properties" className="text-blue-600 font-medium">
                Propriedades
              </Link>
              <Link href="/reservations" className="text-gray-600 hover:text-gray-900">
                Reservas
              </Link>
              <Link href="/calendar" className="text-gray-600 hover:text-gray-900">
                Calendário
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Propriedades</h2>
            <p className="text-gray-600 mt-1">
              Gerencie suas propriedades e anúncios
            </p>
          </div>
          <Link
            href="/properties/new"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-5 w-5" />
            Nova Propriedade
          </Link>
        </div>

        {/* Properties List */}
        {!properties || properties.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Home className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Nenhuma propriedade cadastrada
            </h3>
            <p className="text-gray-600 mb-6">
              Comece adicionando sua primeira propriedade para começar a gerenciar seus alojamentos.
            </p>
            <Link
              href="/properties/new"
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              Adicionar Primeira Propriedade
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

function PropertyCard({ property }: { property: any }) {
  return (
    <Link href={`/properties/${property.id}`}>
      <div className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow p-6 cursor-pointer">
        {/* Property Type Badge */}
        <div className="flex items-center justify-between mb-4">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
            {property.property_type || 'Apartamento'}
          </span>
          {property.is_active ? (
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
              Ativo
            </span>
          ) : (
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
              Inativo
            </span>
          )}
        </div>

        {/* Property Name */}
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {property.name}
        </h3>

        {/* Location */}
        <div className="flex items-center gap-2 text-gray-600 mb-4">
          <MapPin className="h-4 w-4" />
          <span className="text-sm">
            {property.city}, {property.country}
          </span>
        </div>

        {/* Details */}
        <div className="flex items-center gap-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Building2 className="h-4 w-4" />
            <span>{property.bedrooms || 0} quartos</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{property.max_guests || 0} hóspedes</span>
          </div>
        </div>
      </div>
    </Link>
  )
}
