import Link from 'next/link'
import { Building2, Calendar, Users, DollarSign } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Home Stay</h1>
            </div>
            <nav className="flex gap-6">
              <Link href="/" className="text-blue-600 font-medium">
                Dashboard
              </Link>
              <Link href="/properties" className="text-gray-600 hover:text-gray-900">
                Propriedades
              </Link>
              <Link href="/reservations" className="text-gray-600 hover:text-gray-900">
                Reservas
              </Link>
              <Link href="/calendar" className="text-gray-600 hover:text-gray-900">
                Calendário
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={<Building2 className="h-6 w-6" />}
            label="Propriedades"
            value="0"
            bgColor="bg-blue-500"
          />
          <StatCard
            icon={<Calendar className="h-6 w-6" />}
            label="Reservas Ativas"
            value="0"
            bgColor="bg-green-500"
          />
          <StatCard
            icon={<Users className="h-6 w-6" />}
            label="Hóspedes"
            value="0"
            bgColor="bg-purple-500"
          />
          <StatCard
            icon={<DollarSign className="h-6 w-6" />}
            label="Receita (Mês)"
            value="€0"
            bgColor="bg-orange-500"
          />
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Ações Rápidas
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              href="/properties/new"
              className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Building2 className="h-5 w-5" />
              Nova Propriedade
            </Link>
            <Link
              href="/reservations/new"
              className="flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Calendar className="h-5 w-5" />
              Nova Reserva
            </Link>
            <Link
              href="/calendar"
              className="flex items-center justify-center gap-2 px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Calendar className="h-5 w-5" />
              Ver Calendário
            </Link>
          </div>
        </div>

        {/* Welcome Message */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-2">
            🎉 Bem-vindo ao Home Stay!
          </h3>
          <p className="text-blue-800 mb-4">
            Seu sistema de gestão de alojamentos está pronto. Comece adicionando suas propriedades.
          </p>
          <Link
            href="/properties/new"
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Adicionar Primeira Propriedade
          </Link>
        </div>
      </main>
    </div>
  )
}

function StatCard({ icon, label, value, bgColor }: {
  icon: React.ReactNode
  label: string
  value: string
  bgColor: string
}) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{label}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
        </div>
        <div className={`${bgColor} text-white p-3 rounded-lg`}>
          {icon}
        </div>
      </div>
    </div>
  )
}
