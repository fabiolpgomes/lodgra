'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'

export default function TestePage() {
  const [resultado, setResultado] = useState<string>('')
  const [loading, setLoading] = useState(false)

  async function testarConexao() {
    setLoading(true)
    setResultado('Testando...')

    try {
      const supabase = createClient()

      // Teste 1: Verificar se cliente foi criado
      console.log('Cliente Supabase:', supabase)
      setResultado('✅ Cliente Supabase criado\n')

      // Teste 2: Tentar buscar dados
      console.log('Buscando plataformas...')
      const { data, error } = await supabase.from('platforms').select('*')

      if (error) {
        console.error('Erro completo:', error)
        setResultado(prev => prev + `\n❌ Erro ao buscar:\n${JSON.stringify(error, null, 2)}`)
        return
      }

      setResultado(prev => prev + `\n✅ Busca funcionou!\n📊 ${data?.length || 0} plataformas encontradas`)

      // Teste 3: Tentar inserir
      console.log('Tentando inserir...')
      const { data: insertData, error: insertError } = await supabase
        .from('properties')
        .insert({
          name: 'Teste Diagnóstico ' + Date.now(),
          address: 'Rua Teste',
          city: 'Teste',
          country: 'Teste',
          property_type: 'apartment'
        })
        .select()

      if (insertError) {
        console.error('Erro ao inserir:', insertError)
        setResultado(prev => prev + `\n\n❌ ERRO AO INSERIR:\n${JSON.stringify(insertError, null, 2)}`)
        return
      }

      setResultado(prev => prev + `\n\n✅ INSERÇÃO FUNCIONOU!\n${JSON.stringify(insertData, null, 2)}`)

    } catch (err: any) {
      console.error('Erro catch:', err)
      setResultado(prev => prev + `\n\n❌ ERRO CATCH:\n${err.message}\n${JSON.stringify(err, null, 2)}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">🔧 Diagnóstico Supabase</h1>

        {/* Variáveis de Ambiente */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Variáveis de Ambiente</h2>
          <div className="space-y-2 font-mono text-sm">
            <div>
              <strong>NEXT_PUBLIC_SUPABASE_URL:</strong>{' '}
              {process.env.NEXT_PUBLIC_SUPABASE_URL ? (
                <span className="text-green-600">✅ {process.env.NEXT_PUBLIC_SUPABASE_URL}</span>
              ) : (
                <span className="text-red-600">❌ NÃO DEFINIDA</span>
              )}
            </div>
            <div>
              <strong>NEXT_PUBLIC_SUPABASE_ANON_KEY:</strong>{' '}
              {process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? (
                <span className="text-green-600">
                  ✅ {process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.substring(0, 20)}...
                </span>
              ) : (
                <span className="text-red-600">❌ NÃO DEFINIDA</span>
              )}
            </div>
          </div>
        </div>

        {/* Botão de Teste */}
        <button
          onClick={testarConexao}
          disabled={loading}
          className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 mb-6"
        >
          {loading ? 'Testando...' : '🚀 Testar Conexão e Inserção'}
        </button>

        {/* Resultado */}
        {resultado && (
          <div className="bg-gray-900 text-green-400 rounded-lg p-6 font-mono text-sm whitespace-pre-wrap">
            {resultado}
          </div>
        )}

        {/* Instruções */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mt-6">
          <h3 className="font-semibold mb-2">📋 Como usar este diagnóstico:</h3>
          <ol className="list-decimal list-inside space-y-1 text-sm">
            <li>Verifique se as variáveis de ambiente estão definidas acima</li>
            <li>Clique no botão "Testar Conexão"</li>
            <li>Veja o resultado no console cinza</li>
            <li>Me envie screenshot do resultado completo</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
